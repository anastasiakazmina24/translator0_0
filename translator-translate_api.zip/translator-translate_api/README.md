# Setup

## install redis

    brew install redis
    brew services start redis

## Setup .env
Copy `.env.sample` to `.env` and setup it to [API][api]

[api]: https://rapidapi.com/orthosie/api/pirate-translator?endpoint=5606da25e4b086f278966be8 

