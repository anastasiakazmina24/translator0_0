require 'test_helper'

class FxTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
