class Api::ApplicationController < ActionController::Base
end
