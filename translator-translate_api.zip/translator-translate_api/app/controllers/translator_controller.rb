class TranslatorController < ApplicationController
  def index
  end
end
