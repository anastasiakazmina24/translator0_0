class SynthroomController < ApplicationController
  def index
  end
end
