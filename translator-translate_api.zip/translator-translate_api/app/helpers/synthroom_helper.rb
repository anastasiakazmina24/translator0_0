module SynthroomHelper
end
